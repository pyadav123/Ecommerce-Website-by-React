import React from 'react'
import CartItems from '../Components/CartItems/CartItems'

const cart = () => {
  return (
    <div>
      <CartItems />
    </div>
  )
}

export default cart
